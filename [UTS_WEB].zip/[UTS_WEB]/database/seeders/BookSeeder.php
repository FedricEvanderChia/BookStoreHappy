<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('books')->insert([
            ['title'=>'IF THERE WAS TIME','category_id'=> 1],
            ['title'=>'Is There Still Anything Love Can Do?','category_id'=> 1],
            ['title'=>'Caesura of Despair','category_id'=> 1],
            ['title'=>'Unlasting','category_id'=> 1],
            ['title'=>'Please Do Not Be Happy','category_id'=> 1],

            ['title'=>'The Science Book: Everything You Need to Know About the World and How It Works','category_id'=> 2],
            ['title'=>'Breath: The New Science of a Lost Art','category_id'=> 2],
            ['title'=>'The Fascinating Science Book for Kids: 500 Amazing Facts! (Fascinating Facts)','category_id'=> 2],
            ['title'=>'The Science Book: Big Ideas Simply Explained','category_id'=> 2],
            ['title'=>'Humble Pi: When Math Goes Wrong in the Real World','category_id'=> 2],
            
            ['title'=>'Beginners Step-by-Step Coding Course: Learn Computer Programming the Easy Way','category_id'=> 3],
            ['title'=>'BUILD YOUR OWN GAMING COMPUTER: A Step-by-Step Illustrated Guide to Assembling Your Ultimate High-Performance PC','category_id'=> 3],
            ['title'=>'Twenty Things to Do with a Computer Forward 50: Future Visions of Education Inspired by Seymour Papert and Cynthia Solomon’s Seminal Work','category_id'=> 3],
            ['title'=>'Structure and Interpretation of Computer Programs - 2nd Edition (MIT Electrical Engineering and Computer Science)','category_id'=> 3],
            ['title'=>'Computers Made Easy: From Dummy To Geek','category_id'=> 3],

            ['title'=>'AVATAR: The Last Airbender Book III','category_id'=> 8],
            ['title'=>'How To Basic','category_id'=> 9],
            ['title'=>'5 Feet Apart','category_id'=> 10],
            ['title'=>'Once Upon Rimuru Tempest','category_id'=> 11],
            ['title'=>'100 Jokes On You','category_id'=>4],
            ['title'=>'100 Quotes For All Except You','category_id'=> 5],
            ['title'=>'The Story of Stan Lee','category_id'=> 6]




        ]);
    }
}
