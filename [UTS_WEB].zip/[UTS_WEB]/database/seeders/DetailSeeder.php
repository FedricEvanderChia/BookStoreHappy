<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DetailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('details')->insert([
            ['book_id'=> 1, 'author'=>'Fedric Evander Chia', 'publisher'=>'Erlangga', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 2, 'author'=>'Radwimps', 'publisher'=>'Erlangga', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 3, 'author'=>'IRyS', 'publisher'=>'Erlangga', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 4, 'author'=>'LiSA', 'publisher'=>'Erlangga', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 5, 'author'=>'Harutya', 'publisher'=>'Erlangga', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],

            ['book_id'=> 6, 'author'=>' National Geographic and Marshall Brain', 'publisher'=>'FECJST', 'year'=> 2011, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 7, 'author'=>'James Nestor and Penguin Audio', 'publisher'=>'FECJST', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 8, 'author'=>'Kevin Kurtz MA', 'publisher'=>'FECJST', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 9, 'author'=>'DK', 'publisher'=>'FECJST', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 10, 'author'=>'Matt Parker', 'publisher'=>'FECJST', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],

            ['book_id'=> 11, 'author'=>'DK', 'publisher'=>'Sinar', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 12, 'author'=>' C.S. Barnett and Melissa Drozdowski', 'publisher'=>'Sinar', 'year'=> 2021, 'description'=>'Buying a new PC usually means settling for a computer that doesnt match your budget or your needs. And its often an exercise in frustration. So, whats the solution? Building your own, of course.
            Assembling your own computer isnt as scary, complicated, or expensive as it sounds. All you really need is a good guide to show you how.'],
            ['book_id'=> 13, 'author'=>'Gary S. Stager and Cynthia Solomon', 'publisher'=>'Sinar', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 14, 'author'=>'by Harold Abelson , Gerald Jay Sussman , et al.', 'publisher'=>'Sinar', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],
            ['book_id'=> 15, 'author'=>'James Bernstein', 'publisher'=>'Sinar', 'year'=> 2020, 'description'=>'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quibusdam cupiditate quis quae perspiciatis dolorem repellendus praesentium expedita deleniti commodi atque, voluptatibus quia delectus, ipsa aliquid explicabo quo maiores rerum natus.'],

            ['book_id'=> 16, 'author'=>'Bryan Konietzko', 'publisher'=>'Nickelodeon', 'year'=> 2007, 'description'=>'the story of Aang, a thirteen-year-old Airbender who ran away from his destiny as the Avatar. After a hundred years in suspended animation, Aang travels to the Northern Water Tribe on the other side of the world with his newfound friends, Katara and Sokka, to find a master to teach him waterbending. In his absence, the Fire Nation, now ruled by Fire Lord Ozai, has been waging a seemingly endless war against the Earth Kingdom and the Water Tribe, having already destroyed the Air Nomads. As the Avatar, he is hunted by Zuko, an exiled prince of the Fire Nation seeking to redeem his honor, and the Fire Nation itself, led by Commander Zhao.'],

            ['book_id'=> 17, 'author'=>'HowToBasic', 'publisher'=>'YouTube', 'year'=> 2015, 'description'=>'Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs Eggs (╯°□°）╯︵ ┻━┻'],

            ['book_id'=> 18, 'author'=>'Rachael Lippincott', 'publisher'=>'Stars', 'year'=> 2019, 'description'=>'In this moving story that’s perfect for fans of John Green’s The Fault in Our Stars, two teens fall in love with just one minor complication - they can’t get within a few feet of each other without risking their lives.

            Can you love someone you can never touch?'],

            ['book_id'=> 19, 'author'=>'NotRimuru', 'publisher'=>'Slime', 'year'=> 2018, 'description'=>'The Spin-off Story of how a slime became a demon lord by being such a glutton'],

            ['book_id'=> 20, 'author'=>'Fedric Evander Chia', 'publisher'=>'Ice Wallow Come', 'year'=> 2019, 'description'=>'You probably think this book is not even that funny. Well You know what? JOKES ON YOU!! This book does not even exist to begin with.'],

            ['book_id'=> 21, 'author'=>'Fedric Evander Chia', 'publisher'=>'Ice Wallow Come', 'year'=> 2021, 'description'=>'A Sequel of the book 100 Jokes On You, but this time the writer actually encourage people to move to the future with some great couples of quotes that will lighten up everyones day by making people feel good about themself by making fun of you.'],

            ['book_id'=> 22, 'author'=>'Frank J. Berrios', 'publisher'=>'Daily Bugle', 'year'=> 2021, 'description'=>'Stan Lee was a famous comic book writer, artist, editor, and publisher for Marvel Comics. Before he helped create heroes like the Incredible Hulk, Spider-Man, the X-Men, and Black Panther, Stan was an imaginative boy who spent hours reading all sorts of different stories and letting his thoughts run wild. These stories inspired him to come up with exciting plots and new characters of his own. Explore how Stan went from being a young boy growing up in New York City to a comic book legend.'],
        ]);
    }
    
}
