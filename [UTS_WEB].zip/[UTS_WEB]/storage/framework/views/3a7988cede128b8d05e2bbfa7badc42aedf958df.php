

<?php $__env->startSection('content'); ?>
<div class="d-flex">
    <div id="bookList" class="flex-grow-1 me-5">
        <h1 class="bg-warning display-6 px-3"><?php echo e($selectedCategory->category); ?></h1>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Title</th>
                    <th scope="col">Author</th>
                </tr>
            </thead>
            <?php if(!$books->isEmpty()): ?>
            <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row">
                        <a href="/books/<?php echo e($book->id); ?>" class="text-decoration-none text-black" title="<?php echo e($book->title); ?>"><?php echo e($book->title); ?></a>
                    </td>
                    <td><?php echo e($book->detail->author); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            <?php else: ?>
                <tr>
                    <td class="bg-warning">No data</td>
                    <td class="bg-warning"></td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
    <div id="categories">
        <h1 class="bg-warning display-6 ps-3 pe-5">Category</h1>
        <ul class="list-unstyled">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="ms-2 p-1"><a href="/categories/<?php echo e($category->id); ?>" class="text-decoration-none"><?php echo e($category->category); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Exam\Laravel\[UTS_WEB]\resources\views/Category.blade.php ENDPATH**/ ?>