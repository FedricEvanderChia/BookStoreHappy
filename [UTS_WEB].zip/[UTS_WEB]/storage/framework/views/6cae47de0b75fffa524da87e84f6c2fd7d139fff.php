

<?php $__env->startSection('content'); ?>
<div class="d-flex">
    <div id="bookList" class="flex-grow-1 me-5">
        <h1 class="bg-warning display-6 px-3">Book Detail</h1>
        <p>Title : <?php echo e($book->title); ?></p>
        <p>Author : <?php echo e($book->detail->author); ?></p>
        <p>Publisher : <?php echo e($book->detail->publisher); ?></p>
        <p>Year : <?php echo e($book->detail->year); ?></p>
        <p>Description :</p>
        <p><?php echo e($book->detail->description); ?></p>
    </div>
    <div id="category">
        <h1 class="bg-warning display-6 ps-3 pe-5">Category</h1>
        <ul class="list-unstyled">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="ms-2 p-1"><a href="/categories/<?php echo e($category->id); ?>" class="text-decoration-none"><?php echo e($category->category); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Exam\Laravel\[UTS_WEB]\resources\views/BookDetail.blade.php ENDPATH**/ ?>