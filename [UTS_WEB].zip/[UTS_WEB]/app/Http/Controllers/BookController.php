<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function defaultHome(){
        $books = Book::with('detail')->get();
        $categories = Category::all();
        return view('Home')->with(['books' => $books])
        ->with(['categories' => $categories]);
    }
    public function categoryFilter($categoryId){
        $books = Book::where('category_id', $categoryId)->with('detail')->get();
        $categories = Category::all();
        $selectedCategory = Category::where('id', $categoryId)->first();
        return view('Category')->with(['books' => $books])
        ->with(['categories' => $categories])
        ->with(['selectedCategory' => $selectedCategory]);
    }

    public function bookDetail($bookId) {
        $book = Book::where('id', $bookId)->with('detail')->first();
        $categories = Category::all();
        return view('BookDetail')->with(['book' => $book])
        ->with(['categories' => $categories]);
    }

    public function ContactUs(){
        $categories = Category::all();
        return view('Contact')->with(['categories' => $categories]);
    }
}
