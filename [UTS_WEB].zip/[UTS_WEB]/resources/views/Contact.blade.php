@extends('template')

@section('content')
<div class="d-flex">
    <div id="bookList" class="flex-grow-1 me-5">
        <h1 class="bg-warning display-6 px-3">Contact</h1>
        <div id="store-address">
            <h4>Store Address:</h4>
            <p>Jalan Pembangunan Baru Raya,</p>
            <p>Kompleks Pertokoan Emerald Blok Il/12</p>
            <p>Bintaro, Tangerang Selatan</p>
            <p>Indonesia</p>
        </div>
        <div id="open-daily">
            <h4>Open Daily</h4>
            <p>08.00 - 20.00</p>
        </div>
        <div id="contact">
            <h4>Contact</h4>
            <p>Phone : 021-08899776655</p>
            <p>Email : happybookstore@happy.com</p>
        </div>
    </div>
    <div id="categories">
        <h1 class="bg-warning display-6 ps-3 pe-5">Category</h1>
        <ul class="list-unstyled">
            @foreach ($categories as $category)
            <li class="ms-2 p-1"><a href="/categories/{{$category->id}}" class="text-decoration-none">{{$category->category}}</a></li>
            @endforeach
        </ul>
    </div>
</div>
@endsection