@extends('template')

@section('content')
<div class="d-flex">
    <div id="bookList" class="flex-grow-1 me-5">
        <h1 class="bg-warning display-6 px-3">{{$selectedCategory->category}}</h1>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Title</th>
                    <th scope="col">Author</th>
                </tr>
            </thead>
            @if (!$books->isEmpty())
            <tbody>
            @foreach ($books as $book)
                <tr>
                    <td scope="row">
                        <a href="/books/{{$book->id}}" class="text-decoration-none text-black" title="{{$book->title}}">{{$book->title}}</a>
                    </td>
                    <td>{{$book->detail->author}}</td>
                </tr>
            @endforeach
                </tbody>
            @else
                <tr>
                    <td class="bg-warning">No data</td>
                    <td class="bg-warning"></td>
                </tr>
            @endif
        </table>
    </div>
    <div id="categories">
        <h1 class="bg-warning display-6 ps-3 pe-5">Category</h1>
        <ul class="list-unstyled">
            @foreach ($categories as $category)
            <li class="ms-2 p-1"><a href="/categories/{{$category->id}}" class="text-decoration-none">{{$category->category}}</a></li>
            @endforeach
        </ul>
    </div>
</div>
@endsection